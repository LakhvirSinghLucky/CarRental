<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>footer</title>
    <link rel="stylesheet" href="css/style4.css">
</head>
<body>
<footer>
    <div bottom class="footer-nav">
        <a href="home2.php">Home</a>
        <a href="contact2.php">Contact Us</a>
        <a href="after login about.php">About</a>
        <a href="t&d2.php">Terms&condition</a>
        <a href="FYQ2.php">FYQ</a>
    </div>
    
    </div>
    <div class="footer-copy">
        © <?php echo date('Y'); ?> Car RentaL. All rights reserved.
    </div>
</footer>
</body>
</html>
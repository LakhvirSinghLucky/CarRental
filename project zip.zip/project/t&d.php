<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php include "navbar.php"; ?>
 
<P text="red"><h1> # Terms and Conditions</h1><br><br>

<h3>Welcome to our car booking website! By using our services, you agree to be bound by the following terms and conditions:</h3><br><br>
<br>
<h4>## 1. Account Creation</h4>
<br><br>
To use our services, you must create an account and provide accurate and complete information. You are responsible for maintaining the confidentiality of your account and password, and for restricting access to your computer.
<br><br>
<h4>## 2. Car Rental</h4>
<br><br>
You must be at least 21 years old to rent a car through our website. You are responsible for inspecting the car before you drive away and reporting any damage to us. You agree to return the car in the same condition you received it, except for normal wear and tear.
<br><br>
<h4>## 3. Payment</h4>
<br><br>
You agree to pay all fees associated with your rental, including any additional fees for damages or late returns. Payment is due at the time of rental, and you authorize us to charge your credit card or other payment method for any fees incurred.
<br><br>
<h4>## 4. Cancellation Policy</h4>
<br><br>
You may cancel your reservation up to 24 hours before the rental start time without penalty. If you cancel within 24 hours of the rental start time, you will be charged a cancellation fee.
<br><br>
<h4>## 5. Prohibited Uses</h4>
<br><br>
You agree not to use our services for any illegal or unauthorized purpose, and not to violate any laws or regulations in your jurisdiction.
<br><br>
<h4>## 6. Disclaimer of Warranties</h4>
<br><br>
Our services are provided "as is" and "as available," without any warranty of any kind, express or implied. We do not warrant that our services will be uninterrupted or error-free.
<br><br>
<h4>## 7. Limitation of Liability</h4>
<br><br>
In no event shall we be liable for any damages, including but not limited to direct, indirect, special, incidental, or consequential damages, arising out of or in connection with the use of our services.
<br><br>
<h4>## 8. Governing Law</h4>
<br><br>
These terms and conditions shall be governed by and construed in accordance with the laws of the jurisdiction in which our company is registered.
<br><br>

<h4>## 9. Changes to Terms and Conditions</h4>
<br><br>
We reserve the right to modify these terms and conditions at any time. Your continued use of our services constitutes your acceptance of any modified terms and conditions.<p>



<?php include "footer bar.php"; ?>
</body>
</html>
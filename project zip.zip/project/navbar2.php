<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/signinav.css">
</head>
<body>
    <div class="navbar">
        <div class="left-side">
            <a href="home2.php"><h4>Home</h4></a>
          
            <a href="After login about.php"><h4>About Us</h4></a>
            <a href="extraaa.php"><h4>Cars</h4></a>
            
            </div> 
            <div class="center-side">
            <h1>Car RentaL</h1>
        </div>
    <div class="login">
   <a href="home.php"><h4>Sign out</h4></a>
</div></div>
</body>
</html>

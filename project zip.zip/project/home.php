
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>
    
    <link rel="stylesheet" href="css/homestyle.css">
    <link rel="stylesheet" href="css/style4.css">
    <link rel="stylesheet" href="css/marquee.css">
    
</head>
<body>
    <?php include "navbar.php"; ?>
    <marquee behaviour=scroll ><h2>Life is a highway. Rent a car and enjoy the ride.</h2></marquee>
   
   <h2>Welcome to Our Car Riding Website</h2>
  <p class="cardTeXT"> <h4>We offer a wide range of car riding services to meet your needs.</h4></p> 
  <?php include "slider.html";?><br><br><br>

  <a href="cars.php"><button class="book-button"> Click for Cars </button></a>
  
    
    <?php include "footer bar.php";?>
    

    
</body>
</html>
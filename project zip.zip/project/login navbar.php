<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Document</title>
    <link rel="stylesheet" href="css/signinav.css">
</head>
<body>
    <div class="navbar">
        <div class="left-side">
            <a href="home.php"><h4>Home</h4></a>
            <a href="About.php"><h4>About Us</h4></a>
            <a href="cars.php"><h4>Cars</h4></a>
        </div>
        <center id=" Car RentaL">
            <h1>Car RentaL</h1>
        </center>
        <div class="login">
            <a href="r4.php"><h4>Signup</h4></a>
        </div>
    </div>
</body>
</html>

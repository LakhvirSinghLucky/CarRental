<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Booking</title>
    <style>
        body {
            
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            
        }
.n1{
    color: red;
}
        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 2rem;
            background-color: #f5f5f5;
            min-height: 100vh;
        }

        form {
            width: 100%;
            max-width: 30rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
        }

        input[type="text"],
        input[type="date"],
        select {
            width: 100%;
            padding: 0.5rem;
            margin-bottom: 1rem;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .day-night-toggle {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
        }

        .day-night-toggle label {
            margin-right: 1rem;
        }

        .clock{
            font-size: 1.5rem;
            margin-bottom: 1rem;
        }

        .radio-container {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
        }

        .radio-container label {
            margin-right: 1rem;
        }

        @media (prefers-color-scheme: dark) {
            body {
                background-color: #333;
            }

            .container {
                background-color: #444;
            }

            .clock {
                color: #fff;
            }
        }
    </style>
      
</head>
<body>
    <?php include "navbar2.php";
    ?>
<?php   

if(isset($_POST["submit"])) {
    
    include "database/Database.php";

    
    $name = $_POST["name"];
    $email = $_POST["email"];
    $from = $_POST["from"]; 
    $to = $_POST["to"]; 
    $date = $_POST["pickup-date"]; 
    $day = $_POST["day"]; 
    $night = $_POST["night"]; 
            $result = mysqli_query($con, "INSERT INTO carbooking  VALUES ('','$email','$name','$from', '$to', '$date', '$day','$night')");
            if ($result) {
                
                echo '<script>alert("Your car has been booked!"); window.location.href = "extraaa.php";</script>';
                
                exit();
            } else {
                echo '<script>alert("Error occurred while inserting data into database at empty file"); window.location.href = "carbooking.php";</script>';
                exit();
            }
        }

?>


    <div class="container">
        <h1 class="n1">Book Your Ride</h1>
        <form action="" method="post">
           
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" placeholder="Enter your Full name" required>
            <label for="name">Email:</label>
            <input type="text" id="name" name="email" placeholder="Enter your Email" required>
            <label for="From">From:</label>
            <input type="text" id="From" name="from" placeholder="Starting point" required>

            <label for="To">To:</label>
            <input type="text" id="To" name="to" placeholder="Destination point" required>

            <label for="pickup-date">Pickup Date:</label>
            <input type="date" id="pickup-date" name="pickup-date" required>
            <div class="day-night-toggle"> 
                <label >Day/Night:</label>

                <input type="radio" id="day" name="day_night" value="day" checked>
                <label for="day">Day</label>&nbsp;

                <input type="radio" id="night" name="day_night" value="night">
                <label for="night">Night</label>
            </div>
            <input type="submit" value="Book Now"  name="submit" onclick="booknow()">
        </form>
    </div>
    

    <?php include "footer bar.php";?>


</body>
</html>
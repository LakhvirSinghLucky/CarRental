<html>
    <body>
        <center>
            <form method="post" action="">
              <table border="2">
 <tr> 
  <td>Name</td>
  <td><input type="text" name="Name"   placeholder="Enter your Name"   required></td>
</tr>
<tr>
    <td>Phone no.</td>
    <td><iniput type="number" name="Phone no." placeholder="Enter your Phone no." required></td>
</tr>
<td>Email</td>
    <td><iniput type="varchar" name="Email" placeholder=" Enter your Email" required></td>
</tr>
<td>Password</td>
    <td><iniput type="Password" name="Password" placeholder="Enter your Password." required></td>
</tr>

<td> Confirm Password</td>
    <td><iniput type="Password" name=" Confirm Password" placeholder="Confirm your Password." required></td>
</tr>
<tr>
    <td><iniput type="submit" name="submit" value="submit" required> Register</td>
</tr>
</table>
</form>
</center>
</body>
    </html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
    
    <link rel="stylesheet" href="css/aboutcss.css">
    <link rel="stylesheet" href="css/style4.css">
</head>
<body>
    <?php include "navbar.php";?>
<h1>Car Booking FAQ</h1>
<h3>How can I book cheap cars online?<BR>
Car Rental helps you with online cab booking at the best prices, comparatively much lower than the local vendors. Also you can use promo codes and offers on the Car Rental website & app on online cab booking to get extra discounts.
<BR><BR><BR>
What are the advantages of online taxi booking?<BR>
Online taxi booking not only helps you with best prices but also helps you with the convenience of paying through multiple payment options (like Debit Card, Credit Card, eWallets etc.). You can easily compare prices and choose various categories of cars like Hatchback cars, Sedan and SUV.
<BR><BR><BR>
Why you should book cars from Car Rental?<BR>
From Car Rental you can get confirmed cheap cars of your choice and budget. Expert and verified drivers will be taken care of your ride. Easy interface of booking with different payment modes available at Car Rental and finally with no hidden charges, Car Rental is the best option for online taxi booking.
<BR><BR><BR>
What are the best options available for cab booking?<BR>
While booking cars online through Car Rental, you can choose the car based on your requirement and preferences. You can book Hatchback like Indica, Swift, Sedan like Dzire, Etios and SUV like Innova, Ertiga.
<BR><BR><BR>
What kind of cars you can book from Car Rental?<BR>
You can book following kinds of cars from Car Rental:  cars and intercity cars / outstation cars. You can book outstation cars for both one-way transfers & round-trip transfers.
<BR><BR><BR>
Do I need to register on Car Rental to book a cab online?<BR>
No, you can successfully book the cab without registering on our website.
<BR><BR><BR>
How does it work?<BR>
We ask you a few simple questions regarding your trip. We work with the best operators in your city to get you detailed quotations so that you get the best deal.
<BR><BR><BR>
What if the cab doesn't show up?<BR>
If the vehicle you booked does not arrive, we will immediately issue a complete refund.
<BR><BR><BR>
Which cities are you operational in?<BR>
We are currently operational in many cities such as Bangalore, Mumbai, Pune, Chennai, Hyderabad, Delhi, Ahmedabad, Madurai, Mysore, Visakhapatnam, Surat, Vadodara, Vijayawada, Coimbatore, Goa, Pondicherry, Erode, Ooty, Udaipur, Jaipur, Guwahati, Trichy, Kolkata, and many more.
<BR><BR><BR>
What happens if the vehicle breaks down?<BR>
Since we work with the best operators, the vehicles are usually reliable. In case of a breakdown, it is the operator's responsibility to replace the vehicle during the journey.
<BR><BR><BR>
How are the Kilometers calculated?<BR>
The 'Kilometers' are calculated based on the return trip distance between the boarding point and the destination. Any additional distance covered within the city between the Garage and the pickup point is also included in it.
<BR><BR><BR>
Can I book a cab without credit/card or net banking option?<BR>
Yes, other payment options available are UPI(gpay, phone available) wallets (paytm,amazon pay), debit card.
<BR><BR><BR>
How is the total cab fare calculated for an intercity cab service?<BR>
For outstation trips(intercity), mostly x kms included in fare. route wise charges will vary. Sometimes toll, state taxes might be included in the fare. certain cases, these won't be part of the original fare and user would have to pay at trip end whatever extra charges are applicable extra charges can be - Waiting charges Extra KMs charges Extra hours charges Night charges Entry fee  Parking charges Toll charges State Tax Driver charges Parking charges
<BR><BR><BR>
How is the total cab fare/price calculated for a local cab service?<BR>
4 packages available (4hrs & 40 kms, 8hrs & 80 kms, 12hrs & 120 kms, 24hrs & 300kms). extra kms & extra hours charges applicable if usage exceeds the package taken
<BR><BR><BR>
What are the payment terms?<BR>
You can confirm your reservation by paying a small booking fee, typically up to to 25% of the base fare. The balance can be paid directly to us through online modes till two days before the start of the journey or to the operator in cash at the time of boarding.
<BR><BR><BR>
What if I need to cancel my trip?<BR>
The cancellation policy is specific to each operator and is listed against the quotes on the quotations page.
<BR><BR><BR>

How are tolls & taxes calculated?<BR>
Tolls and Interstate taxes are best estimates only. If these amounts are included in the fare, you'll be charged/reimbursed for any difference between the actuals and estimates, as applicable.
</h3>

    <?php include "footer bar.php";?>

</body>
</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CONTACT</title>

    <link rel="stylesheet" href="css/style4.css">
    <link rel="stylesheet" href="css/navbAR2style.css">
    <link rel="stylesheet" href="css/contactcss.css">

</head>

<body>
    <?php include "navbar.php"; ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Contact Information</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 0;
                background-color: #f2f2f2;
            }

            .container {
                max-width: 800px;
                margin: 20px auto;
                background-color: #fff;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            }

            h2 {
                color: #333;
                margin-bottom: 20px;
            }

            .contact-info {
                display: grid;
                grid-template-columns: 1fr 1fr;
                grid-gap: 20px;
            }

            .contact-info h3 {
                margin-top: 0;
                color: #666;
            }

            .contact-info p {
                margin: 5px 0;
            }
        </style>
    </head>

    <body>

        <div class="container">
            <h2 style="color:red;">Contact Information</h2>
            <div class="contact-info">
                <div>
                    <h3>Address:</h3>
                    <p>123 Main Street</p>
                    <p>City:Jalandhar
                    <p>PUNJAB, India</p>
                </div>
                <div>
                    <h3>Phone</h3>
                    <p>6665568569</p>
                    <p>4453567897</p>
                </div>
                <div>
                    <h3>Email</h3>
                    <p>carrental3@gmail.com</p>
                </div>
                <div>
                    <h3>Follow Us</h3>
                    <p>Facebook: <a href="#">CarRental</a></p>
                    <p>Twitter: <a href="#">CarRental</a></p>
                    <p>Instagram: <a href="#">CarRental</a></p>
                </div>
            </div>
        </div>

    </body>

    </html>





</body>

</html>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<?php include "footer bar.php"; ?>

</body>

</html>
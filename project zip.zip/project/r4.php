<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Booking Site - Registration</title>

    <link rel="stylesheet" href="css/r4style.css">
    <link rel="stylesheet" href="css/style4.css">

</head>


<body>

    <?php include "sign in nav bar.php"; ?>
    <br>
    <br>
    <?php


    if (isset($_POST["submit"])) {

        include "database/Database.php";

        $name = $_POST["name"];
        $phone = $_POST["phone"];
        $email = $_POST["email"];
        $Password = $_POST["password"];
        $confirm_password = $_POST["confirm-password"];

        $result = mysqli_query($con, "SELECT * FROM `signup` WHERE phone_num = '$phone'");
        $numExistRows = mysqli_num_rows($result);
        if ($numExistRows > 0) {
            echo '<script>alert("ERROR !! Phone no. already exists!!"); window.location.href ="r4.php"</script>';
            exit();
        } else {
            $result = mysqli_query($con, "SELECT * FROM `signup` WHERE email = '$email'");
            $numExistRows = mysqli_num_rows($result);
            if ($numExistRows > 0) {
                echo '<script>alert("Email already exists !!"); window.location.href = "r4.php";</script>';
                exit();
            } else {
                if (($Password != $confirm_password) || ($confirm_password != $Password)) {
                    echo '<script>alert("Confirm Password do not match !!"); window.location.href = "r4.php";</script>';
                    exit();
                }
                $result = mysqli_query($con, "INSERT INTO signup VALUES ('','$name','$phone','$email','$Password')");
                var_dump($result);
                if ($result) {
                    header("location:login.php?profile_updated=1");
                    exit();
                } else {
                    echo '<script>alert("Error occurred while inserting data into database at empty file"); window.location.href = "r4.php";</script>';
                    exit();
                }
            }
        }
    }
    ?>
    <div class="container">
        <h1>Create an Account</h1>
        <form action="" method="post">
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="name">Phone no.</label>
                <input type="tel" id="Phone no." size="12" maxlength="10" name="phone" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="confirm-password">Confirm Password</label>
                <input type="password" id="confirm-password" name="confirm-password" required>
            </div>
            <button type="submit" name="submit">Register</button>

        </form>
    </div>

    <br><br><br> <br>

    <?php include "footer bar.php"; ?>
</body>
</html>
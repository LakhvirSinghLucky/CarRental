<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/homestyle.css">
    <link rel="stylesheet" href="css/slider.css">
    
    <style>
        center#\ Car\ RentaL {
            margin-right: 38em;
        }
    </style>
</head>

<body>
    <?php include "navbar2.php"; ?>
    
    <marquee behaviour=scroll ><h2>Life is a highway. Rent a car and enjoy the ride.</h2></marquee>
   
    </marquee>

    <h2>Welcome to Our Car Riding Website</h2>
    <p class="cardText">
    <h4>We offer a wide range of car riding services to meet your needs.</h4>
    </p>

    <?php include "slider.html";?><br><br><br>

    <a href="extraaa.php"><button class="book-button"> Click for Cars </button></a>

    <br><br><br><br><br><br><br><br><br>
    <br><br><br><br><br><br><br><br>
    <br><br><br><br><br><br><br><br>

    <?php include "footer bar2.php"; ?>


</body>

</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Booking Site - Registration</title>
    
    <link rel="stylesheet" href="css/login.css">
    
</head>

<body>

    <?php include "login navbar.php"; ?>
    <?php

    if (isset($_POST["submit"])) {

        include "database/Database.php";

        $email = $_POST["email"];
        $Password = $_POST["password"];

        $result = mysqli_query($con, "SELECT * FROM `signup` WHERE Email = '$email'");
        $numExistRows = mysqli_num_rows($result);
        if ($numExistRows === 1) {
            $row = mysqli_fetch_assoc($result);
            $result = mysqli_query($con, "SELECT * FROM `signup` WHERE Password = '$Password'");
            $numExistRows = mysqli_num_rows($result);
            if ($numExistRows === 1) {
                echo '<script>alert("Login Successfull !!"); window.location.href = "home2.php";</script>';
            } else {
                echo "Wrong password";
            }
        }else{
            echo"Wrong email id";
        }
    }
    ?>
    <div class="container">
        <h1>Login</h1>
        <form action="" method="post">
            <div class="form-group">
                <label for="name">Email</label>
                <input type="text" id="name" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
          <input type="submit" value="submit" name="submit">
            <a href="r4.php" class="buttons">Register! If new user.</a>
        </form>
    </div>

    <br><br><br> <br>

    <?php include "footer bar.php"; ?>
</body>

</html>
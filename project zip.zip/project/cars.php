<!DOCTYPE html>
<html>

<head>
	<title>Car Category</title>
	<link rel="stylesheet" href="css/extraaacss.css">
	
</head>

<body>
	<?php include "navbar.php"; ?>
	<div class="containeroutside">
		<div class="car-rental">
			<div class="car-details">
				<img src="logo/HONDA AMAZE.png" alt="Car Image" id="car-112" class="car-image">
				<div class="car-name">HONDA AMAZE</div>
				<div class="car-model"> AMAZE</div>
				<div class="rental-rates">
					<div>Per Day: ₹2000</div>
					<div>Per Night: ₹2200</div>
					<div>Per 20 Kilometer: ₹250</div>
				</div>
				<a href="r4.php"><button class="book-button">Sign in for booking</button></a>
			</div>
		</div>
		<div class="car-rental">
			<div class="car-details">
				<img src="logo/Verna.jpeg" alt="Car Image" class="car-image">
				<div class="car-name">Verna</div>
				<div class="car-model">Verna v6</div>
				<div class="rental-rates">
					<div>Per Day: ₹2000</div>
					<div>Per Night: ₹2200</div>
					<div>Per 20 Kilometer: ₹250</div>
				</div>
				<a href="r4.php"><button class="book-button">Sign in for booking</button></a>
			</div>
		</div>
		<div class="car-rental">
			<div class="car-details">
				<img src="logo/skoda.webp" alt="Car Image" class="car-image">
				<div class="car-name">SKODA</div>
				<div class="car-model">Super S1</div>
				<div class="rental-rates">
					<div>Per Day: ₹2000</div>
					<div>Per Night: ₹2200</div>
					<div>Per 20 Kilometer: ₹250</div>
				</div>
                <a href="r4.php"><button class="book-button">Sign in for booking</button></a>
			</div>


		</div>
		<div class="car-rental">
			<div class="car-details">
				<img src="logo/prius.avif" alt="Car Image" class="car-image">
				<div class="car-name">Toyota Prius</div>
				<div class="car-model">Prius texa</div>
				<div class="rental-rates">
					<div>Per Day: ₹2000</div>
					<div>Per Night: ₹2200</div>
					<div>Per 20 Kilometer: ₹250</div>
				</div>
				<a href="r4.php"><button class="book-button">Sign in for booking</button></a>
			</div>
		</div>
		<div class="car-rental">
			<div class="car-details">
				<img src="logo/inn.jpeg" alt="Car Image" class="car-image">
				<div class="car-name">INNOVA</div>
				<div class="car-model">INNOVA CRYSTAA</div>
				<div class="rental-rates">
					<div>Per Day: ₹5000</div>
					<div>Per Night: ₹3200</div>
					<div>Per 20 Kilometer: ₹650</div>
				</div>
				<a href="r4.php"><button class="book-button">Sign in for booking</button></a>
			</div>
		</div>
		<div class="car-rental">
			<div class="car-details">
				<img src="logo/baleno.jpg" alt="Car Image" class="car-image">
				<div class="car-name">Baleno</div>
				<div class="car-model"> Baleno B5</div>
				<div class="rental-rates">
					<div>Per Day: ₹5000</div>
					<div>Per Night: ₹4200</div>
					<div>Per 20 Kilometer: ₹850</div>
				</div>
				<a href="r4.php"><button class="book-button">Sign in for booking</button></a>
			</div>
		</div>
		<div class="car-rental">
			<div class="car-details">
				<img src="logo/G Vitaara.jpeg" alt="Car Image" class="car-image">
				<div class="car-name">Grand Vitaara</div>
				<div class="car-model">Vitaara v2 </div>
				<div class="rental-rates">
					<div>Per Day: ₹2000</div>
					<div>Per Night: ₹2200</div>
					<div>Per 20 Kilometer: ₹250</div>
				</div>
                <a href="r4.php"><button class="book-button">Sign in for booking</button></a>
			</div>
		</div>
		<div class="car-rental">
			<div class="car-details">
				<img src="logo/lancer.avif" alt="Car Image" id="car-112" class="car-image">
				<div class="car-name">Mitsubishi Lancer</div>
				<div class="car-model"> lanncer l5</div>
				<div class="rental-rates">
					<div>Per Day: ₹2000</div>
					<div>Per Night: ₹2200</div>
					<div>Per 20 Kilometer: ₹250</div>
				</div>
				<a href="r4.php"><button class="book-button">Sign in for booking</button></a>
			</div>
		</div>
		<div class="car-rental">
			<div class="car-details">
				<img src="logo/volkswagen passat.avif " alt="Car Image" id="car-112" class="car-image">
				<div class="car-name">Wolks Wagon Passat</div>
				<div class="car-model"> Passat P9</div>
				<div class="rental-rates">
					<div>Per Day: ₹2000</div>
					<div>Per Night: ₹2200</div>
					<div>Per 20 Kilometer: ₹250</div>
				</div>
                <a href="r4.php"><button class="book-button">Sign in for booking</button></a>
			</div>
		</div>
		<div class="car-rental">
			<div class="car-details">
				<img src="logo/Kia.jpg" alt="Car Image" id="car-112" class="car-image">
				<div class="car-name">Kia</div>
				<div class="car-model"> K6</div>
				<div class="rental-rates">
					<div>Per Day: ₹2000</div>
					<div>Per Night: ₹2200</div>
					<div>Per 20 Kilometer: ₹250</div>
				</div>
				<a href="r4.php"><button class="book-button">Sign in for booking</button></a>
			</div>
		</div>
		<div class="car-rental">
			<div class="car-details">
				<img src="logo/nissan.webp" alt="Car Image" id="car-112" class="car-image">
				<div class="car-name">Nissan Lease</div>
				<div class="car-model"> Lease L1</div>
				<div class="rental-rates">
					<div>Per Day: ₹2000</div>
					<div>Per Night: ₹2200</div>
					<div>Per 20 Kilometer: ₹250</div>
				</div>
				<a href="r4.php"><button class="book-button">Sign in for booking</button></a>
			</div>
		</div>
		<div class="car-rental">
			<div class="car-details">
				<img src="logo/fordf9.jpeg" alt="Car Image" id="car-112" class="car-image">
				<div class="car-name">Ford Fusion</div>
				<div class="car-model"> Fusion F9</div>
				<div class="rental-rates">
					<div>Per Day: ₹2000</div>
					<div>Per Night: ₹2200</div>
					<div>Per 20 Kilometer: ₹250</div>
				</div>
				<a href="r4.php"><button class="book-button">Sign in for booking</button></a>
			</div>
		</div>
		<div class="car-rental">
			<div class="car-details">
				<img src="logo/swift.jpeg" alt="Car Image" id="car-112" class="car-image">
				<div class="car-name">Swift Dezire</div>
				<div class="car-model"> Dezire d6</div>
				<div class="rental-rates">
					<div>Per Day: ₹2000</div>
					<div>Per Night: ₹2200</div>
					<div>Per 20 Kilometer: ₹250</div>
				</div>
				<a href="r4.php"><button class="book-button">Sign in for booking</button></a>
			</div>
		</div>
		<div class="car-rental">
			<div class="car-details">
				<img src="logo/lexus.jpg" alt="Car Image" id="car-112" class="car-image">
				<div class="car-name">Lexus</div>
				<div class="car-model"> Lexus 500</div>
				<div class="rental-rates">
					<div>Per Day: ₹2000</div>
					<div>Per Night: ₹2200</div>
					<div>Per 20 Kilometer: ₹250</div>
				</div>
				<a href="r4.php"><button class="book-button">Sign in for booking</button></a>
			</div>
		</div>
		<div class="car-rental">
			<div class="car-details">
				<img src="logo/Mazda.jpeg" alt="Car Image" id="car-112" class="car-image">
				<div class="car-name">Mazda</div>
				<div class="car-model"> Mazda cx9</div>
				<div class="rental-rates">
					<div>Per Day: ₹2000</div>
					<div>Per Night: ₹2200</div>
					<div>Per 20 Kilometer: ₹250</div>
				</div>
				<a href="r4.php"><button class="book-button">Sign in for booking</button></a>
			</div>
		</div>
		<div class="car-rental">
			<div class="car-details">
				<img src="logo/Sonata.jpeg" alt="Car Image" id="car-112" class="car-image">
				<div class="car-name">Hyundai Sonata</div>
				<div class="car-model"> Sonata s4</div>
				<div class="rental-rates">
					<div>Per Day: ₹2000</div>
					<div>Per Night: ₹2200</div>
					<div>Per 20 Kilometer: ₹250</div>
				</div>
				<a href="r4.php"><button class="book-button">Sign in for booking</button></a>
			</div>
		</div>
	</div>
</body>

</html>
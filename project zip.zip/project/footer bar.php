<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="css/style4.css">
</head>

<body>
    <footer>
        <div bottom class="footer-nav">
            <a href="home.php">Home</a>
            <a href="contact.php">Contact Us</a>
            <a href="About.php">About</a>
            <a href="t&d.php">Terms&condition</a>
            <a href="FYQ.php">FYQ</a>
        </div>

        <div class="footer-copy">
            © 2024 Car RentaL. All rights reserved.
        </div>
    </footer>
</body>

</html>